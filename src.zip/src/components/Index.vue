<template>
  <main>
    <TabletScene />
  </main>
</template>

<script setup lang="ts">
import TabletScene from '@/components/TabletScene.vue'
</script>

<style>
main {
  width: 100%;
  height: 100vh;
}
</style>
