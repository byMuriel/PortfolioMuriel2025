<script setup lang="ts">
import AdminBlog from '@/components/AdminBlog.vue'
</script>

<template>
  <main>
    <AdminBlog />
  </main>
</template>
