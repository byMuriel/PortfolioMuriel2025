<script setup lang="ts">
import Index from '../components/Index.vue'
</script>

<template>
  <main>
    <Index />
  </main>
</template>
