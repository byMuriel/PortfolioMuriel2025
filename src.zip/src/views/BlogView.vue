<script setup lang="ts">
import Blog from '@/components/Blog.vue'
</script>

<template>
  <main>
    <Blog />
  </main>
</template>
